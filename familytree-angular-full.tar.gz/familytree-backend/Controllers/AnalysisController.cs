using Microsoft.AspNetCore.Mvc;
using familytree_backend.Models;
using familytree_backend.Services;
using Npgsql;
using Dapper;

namespace familytree_backend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AnalysisController : ControllerBase
    {
        private readonly AnalysisBackgroundService _analysisService;
        private readonly ILogger<AnalysisController> _logger;
        private readonly IConfiguration _configuration;

        public AnalysisController(
            AnalysisBackgroundService analysisService,
            ILogger<AnalysisController> logger,
            IConfiguration configuration)
        {
            _analysisService = analysisService;
            _logger = logger;
            _configuration = configuration;
        }

        [HttpPost("start")]
        public async Task<IActionResult> StartAnalysis([FromBody] AnalysisRequest request)
        {
            try
            {
                var success = await _analysisService.StartAnalysis(request.PersonId, request.MaxDepth);
                
                if (success)
                {
                    return Ok(new { 
                        success = true, 
                        message = $"遞迴分析已開始（最大深度：{request.MaxDepth}層），請稍後查看進度",
                        personId = request.PersonId,
                        maxDepth = request.MaxDepth
                    });
                }
                else
                {
                    return BadRequest(new { 
                        success = false, 
                        message = "該人員已有進行中的分析任務" 
                    });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "啟動遞迴分析失敗: PersonId = {PersonId}, MaxDepth = {MaxDepth}", request.PersonId, request.MaxDepth);
                return StatusCode(500, new { 
                    success = false, 
                    message = "啟動遞迴分析時發生錯誤" 
                });
            }
        }

        [HttpGet("progress/{personId}")]
        public async Task<IActionResult> GetProgress(int personId)
        {
            try
            {
                var progress = await _analysisService.GetAnalysisProgress(personId);
                
                if (progress == null)
                {
                    return NotFound(new { 
                        success = false, 
                        message = "找不到該人員的分析記錄" 
                    });
                }

                return Ok(new { 
                    success = true, 
                    data = progress 
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "查詢分析進度失敗: PersonId = {PersonId}", personId);
                return StatusCode(500, new { 
                    success = false, 
                    message = "查詢進度時發生錯誤" 
                });
            }
        }



        [HttpGet("jobs")]
        public async Task<IActionResult> GetAnalysisJobs()
        {
            try
            {
                using var connection = new NpgsqlConnection(_configuration.GetConnectionString("DefaultConnection"));
                await connection.OpenAsync();
                
                // 獲取傳統分析記錄
                var traditionalJobs = await connection.QueryAsync(
                    @"SELECT ar.person_id AS personid, 
                             p.name AS personname,
                             ar.status AS status, 
                             ar.progress_percentage AS progresspercentage, 
                             ar.created_at AS starttime, 
                             CASE WHEN ar.status = 'completed' THEN ar.updated_at ELSE NULL END AS completedtime, 
                             ar.current_step AS currentstep,
                             ar.status_message AS statusmessage,
                             'traditional' AS analysistype
                      FROM analysis_results ar
                      LEFT JOIN person_profile p ON ar.person_id = p.id
                      WHERE ar.status IN ('processing', 'completed', 'failed')");

                // 獲取遞迴分析記錄
                var recursiveJobs = await connection.QueryAsync(
                    @"SELECT s.root_person_id AS personid, 
                             p.name AS personname,
                             s.status AS status, 
                             100 AS progresspercentage, 
                             s.created_at AS starttime, 
                             CASE WHEN s.status = 'completed' THEN s.completed_at ELSE NULL END AS completedtime, 
                             '遞迴分析' AS currentstep,
                             '遞迴分析完成' AS statusmessage,
                             'recursive' AS analysistype
                      FROM analysis_sessions s
                      LEFT JOIN person_profile p ON s.root_person_id = p.id
                      WHERE s.status IN ('processing', 'completed', 'failed')");

                // 合併兩種分析記錄
                var allJobs = new List<dynamic>();
                allJobs.AddRange(traditionalJobs);
                allJobs.AddRange(recursiveJobs);

                // 按開始時間排序並去重（如果同一個人有多個記錄，保留最新的）
                var groupedJobs = allJobs
                    .GroupBy(job => job.personid)
                    .Select(group => group.OrderByDescending(job => job.starttime).First())
                    .OrderByDescending(job => job.starttime)
                    .Take(20)
                    .ToList();

                var result = new List<object>();
                foreach (dynamic job in groupedJobs)
                {
                    result.Add(new
                    {
                        PersonId = job.personid,
                        PersonName = job.personname ?? $"人員 {job.personid}",
                        Status = job.status,
                        ProgressPercentage = job.progresspercentage,
                        StartTime = job.starttime,
                        CompletedTime = job.completedtime,
                        CurrentStep = job.currentstep,
                        StatusMessage = job.statusmessage,
                        ErrorMessage = (string?)null
                    });
                }

                return Ok(new { success = true, data = result });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "獲取分析工作列表失敗");
                return StatusCode(500, new { success = false, message = "獲取分析工作列表失敗" });
            }
        }

        [HttpDelete("stop/{personId}")]
        public async Task<IActionResult> StopAnalysis(int personId)
        {
            try
            {
                var result = await _analysisService.StopAnalysis(personId);
                if (result)
                {
                    return Ok(new { success = true, message = "分析工作已終止" });
                }
                else
                {
                    // 檢查工作是否存在
                    using var connection = new NpgsqlConnection(_configuration.GetConnectionString("DefaultConnection"));
                    await connection.OpenAsync();
                    
                    var job = await connection.QueryFirstOrDefaultAsync(
                        "SELECT status FROM analysis_results WHERE person_id = @PersonId",
                        new { PersonId = personId });
                    
                    if (job == null)
                    {
                        return BadRequest(new { success = false, message = "找不到指定的分析工作" });
                    }
                    else
                    {
                        return BadRequest(new { success = false, message = $"分析工作狀態為 '{job.status}'，無法終止" });
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "終止分析工作失敗: PersonId = {PersonId}", personId);
                return StatusCode(500, new { success = false, message = "終止分析工作失敗" });
            }
        }

        [HttpPost("reset/{personId}")]
        public async Task<IActionResult> ResetAnalysis(int personId)
        {
            try
            {
                using var connection = new NpgsqlConnection(_configuration.GetConnectionString("DefaultConnection"));
                await connection.OpenAsync();
                
                // 檢查是否有進行中的任務
                var activeJob = await connection.QueryFirstOrDefaultAsync(
                    "SELECT status FROM analysis_results WHERE person_id = @PersonId AND status IN ('pending', 'processing')",
                    new { PersonId = personId });
                
                if (activeJob != null)
                {
                    return BadRequest(new { success = false, message = "該人員有進行中的分析任務，請先停止任務" });
                }
                
                // 刪除所有相關的分析記錄和會話
                var deletedResults = await connection.ExecuteAsync(
                    "DELETE FROM analysis_results WHERE person_id = @PersonId",
                    new { PersonId = personId });
                
                var deletedSessions = await connection.ExecuteAsync(
                    "DELETE FROM analysis_sessions WHERE root_person_id = @PersonId",
                    new { PersonId = personId });
                
                var deletedLayers = await connection.ExecuteAsync(
                    "DELETE FROM relationship_layers WHERE analysis_session_id IN (SELECT id FROM analysis_sessions WHERE root_person_id = @PersonId)",
                    new { PersonId = personId });
                
                var deletedCount = deletedResults + deletedSessions + deletedLayers;
                
                if (deletedCount > 0)
                {
                    _logger.LogInformation("已重置分析狀態: PersonId = {PersonId}, 刪除記錄數 = {Count}", personId, deletedCount);
                    return Ok(new { success = true, message = "分析狀態已重置，可以重新開始分析" });
                }
                else
                {
                    return Ok(new { success = true, message = "沒有找到需要重置的分析記錄" });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "重置分析狀態失敗: PersonId = {PersonId}", personId);
                return StatusCode(500, new { success = false, message = "重置分析狀態失敗" });
            }
        }

        [HttpGet("result/{personId}")]
        public async Task<IActionResult> GetAnalysisResult(int personId)
        {
            try
            {
                using var connection = new NpgsqlConnection(_configuration.GetConnectionString("DefaultConnection"));
                await connection.OpenAsync();
                
                // 首先檢查遞迴分析會話
                var session = await connection.QueryFirstOrDefaultAsync(
                    @"SELECT s.root_person_id AS personid,
                             p.name AS personname,
                             s.status AS status,
                             s.total_relationships AS totalrelationships,
                             s.created_at AS createdat,
                             s.completed_at AS completedat
                      FROM analysis_sessions s
                      LEFT JOIN person_profile p ON s.root_person_id = p.id
                      WHERE s.root_person_id = @PersonId AND s.status = 'completed'
                      ORDER BY s.created_at DESC
                      LIMIT 1",
                    new { PersonId = personId });
                
                if (session != null)
                {
                    // 獲取遞迴分析的關係結果
                    var relationships = await connection.QueryAsync(
                        @"SELECT rl.source_person_id, rl.target_person_id, rl.relation_type, rl.source_field, rl.layer_depth,
                                 s.name AS source_name, t.name AS target_name
                          FROM relationship_layers rl
                          LEFT JOIN person_profile s ON rl.source_person_id = s.id
                          LEFT JOIN person_profile t ON rl.target_person_id = t.id
                          WHERE rl.analysis_session_id = (SELECT id FROM analysis_sessions WHERE root_person_id = @PersonId AND status = 'completed' ORDER BY created_at DESC LIMIT 1)
                          ORDER BY rl.layer_depth, rl.source_person_id",
                        new { PersonId = personId });
                    
                    return Ok(new { 
                        success = true, 
                        data = new {
                            PersonId = session.personid,
                            PersonName = session.personname ?? $"人員 {session.personid}",
                            AnalysisResult = relationships,
                            AnalysisDate = session.completedat,
                            Status = session.status,
                            TotalRelationships = session.totalrelationships
                        }
                    });
                }
                
                // 如果沒有遞迴分析會話，檢查傳統分析結果
                var result = await connection.QueryFirstOrDefaultAsync(
                    @"SELECT ar.person_id AS personid,
                             p.name AS personname,
                             ar.analysis_result AS analysisresult,
                             ar.analysis_date AS analysisdate,
                             ar.status AS status
                      FROM analysis_results ar
                      LEFT JOIN person_profile p ON ar.person_id = p.id
                      WHERE ar.person_id = @PersonId AND ar.status = 'completed'
                      ORDER BY ar.updated_at DESC
                      LIMIT 1",
                    new { PersonId = personId });
                
                if (result == null)
                {
                    return NotFound(new { 
                        success = false, 
                        message = "找不到該人員的分析結果" 
                    });
                }

                return Ok(new { 
                    success = true, 
                    data = new {
                        PersonId = result.personid,
                        PersonName = result.personname ?? $"人員 {result.personid}",
                        AnalysisResult = result.analysisresult,
                        AnalysisDate = result.analysisdate,
                        Status = result.status
                    }
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "獲取分析結果失敗: PersonId = {PersonId}", personId);
                return StatusCode(500, new { 
                    success = false, 
                    message = "獲取分析結果時發生錯誤" 
                });
            }
        }

        [HttpGet("layers/{personId}")]
        public async Task<IActionResult> GetRelationshipLayers(int personId, [FromQuery] int maxDepth = 10)
        {
            try
            {
                using var connection = new NpgsqlConnection(_configuration.GetConnectionString("DefaultConnection"));
                await connection.OpenAsync();

                // 獲取最新的分析會話
                var session = await connection.QueryFirstOrDefaultAsync(
                    @"SELECT id, root_person_id, max_depth, status, total_relationships, created_at, completed_at
                      FROM analysis_sessions 
                      WHERE root_person_id = @PersonId AND status = 'completed'
                      ORDER BY created_at DESC 
                      LIMIT 1",
                    new { PersonId = personId });

                if (session == null)
                {
                    return NotFound(new { 
                        success = false, 
                        message = "找不到該人員的遞迴分析結果" 
                    });
                }

                // 獲取指定深度內的關係
                var relationships = await connection.QueryAsync(
                    @"SELECT rl.source_person_id, rl.target_person_id, rl.relation_type, rl.source_field, rl.layer_depth,
                             s.name AS source_name, t.name AS target_name
                      FROM relationship_layers rl
                      LEFT JOIN person_profile s ON rl.source_person_id = s.id
                      LEFT JOIN person_profile t ON rl.target_person_id = t.id
                      WHERE rl.analysis_session_id = @SessionId AND rl.layer_depth <= @MaxDepth
                      ORDER BY rl.layer_depth, rl.source_person_id",
                    new { SessionId = session.id, MaxDepth = maxDepth });

                var result = new
                {
                    SessionId = session.id,
                    RootPersonId = session.root_person_id,
                    MaxDepth = session.max_depth,
                    RequestedDepth = maxDepth,
                    TotalRelationships = session.total_relationships,
                    CreatedAt = session.created_at,
                    CompletedAt = session.completed_at,
                    Relationships = relationships
                };

                return Ok(new { 
                    success = true, 
                    data = result 
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "獲取層級關係失敗: PersonId = {PersonId}, MaxDepth = {MaxDepth}", personId, maxDepth);
                return StatusCode(500, new { 
                    success = false, 
                    message = "獲取層級關係時發生錯誤" 
                });
            }
        }
    }
} 