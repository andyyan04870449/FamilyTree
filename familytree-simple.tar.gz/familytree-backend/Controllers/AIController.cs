using Microsoft.AspNetCore.Mvc;
using familytree_backend.Services;

namespace familytree_backend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AIController : ControllerBase
    {
        private readonly AIService _aiService;
        private readonly ILogger<AIController> _logger;

        public AIController(AIService aiService, ILogger<AIController> logger)
        {
            _aiService = aiService;
            _logger = logger;
        }

        /// <summary>
        /// 抽取文字中的人名關係
        /// </summary>
        /// <param name="request">包含要分析文字的請求</param>
        /// <returns>人名關係配對列表</returns>
        [HttpPost("extract-name-relations")]
        public async Task<ActionResult<List<NameRelationPair>>> ExtractNameRelations([FromBody] ExtractNameRelationsRequest request)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(request.TextContent))
                {
                    return BadRequest("文字內容不能為空");
                }

                var result = await _aiService.ExtractNameRelationsAsync(request.TextContent);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in ExtractNameRelations API");
                return StatusCode(500, "處理請求時發生錯誤");
            }
        }

        /// <summary>
        /// 測試API連線
        /// </summary>
        /// <returns>連線狀態</returns>
        [HttpGet("ping")]
        public ActionResult<string> Ping()
        {
            return Ok("AI Service is running");
        }
    }

    /// <summary>
    /// 抽取人名關係的請求模型
    /// </summary>
    public class ExtractNameRelationsRequest
    {
        public string TextContent { get; set; } = string.Empty;
    }
} 