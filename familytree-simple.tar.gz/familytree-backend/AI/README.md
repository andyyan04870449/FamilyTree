# AI 功能說明

## 概述
此目錄包含家族樹後端的AI相關功能，主要用於從文字中抽取人名和關係資訊。

## 檔案結構
```
AI/
├── Templates/
│   ├── extract_name_relation_prompt.json    # Prompt模板
│   └── extract_name_relation_function.json  # Function Calling schema
└── README.md                                 # 本說明文件
```

## 功能說明

### 人名關係抽取 (Extract Name Relations)
- **目的**: 從文字中自動識別人名和其關係
- **輸入**: 文字內容
- **輸出**: 人名關係配對列表

### API 端點
- `POST /api/ai/extract-name-relations` - 抽取人名關係
- `GET /api/ai/ping` - 測試AI服務連線

### 使用範例

#### 請求範例
```json
POST /api/ai/extract-name-relations
{
  "textContent": "李四是張三的老婆，他們育有一子張小明。張三的父親叫張大山，是一位老師。"
}
```

#### 回應範例
```json
[
  {
    "name": "李四",
    "relation": "老婆"
  },
  {
    "name": "張小明",
    "relation": "兒子"
  },
  {
    "name": "張大山",
    "relation": "父親"
  }
]
```

## 配置

### OpenAI API Key
在 `appsettings.json` 中配置您的OpenAI API Key：
```json
{
  "OpenAI": {
    "ApiKey": "your-openai-api-key-here"
  }
}
```

### 環境變數 (推薦)
為了安全性，建議使用環境變數：
```bash
export OPENAI_API_KEY="your-actual-api-key"
```

## 模板修改

### Prompt 模板
修改 `extract_name_relation_prompt.json` 來調整AI的行為：
- `system_message`: 系統指令，定義AI的角色和任務
- `user_message_template`: 使用者訊息模板，`{text_content}` 會被實際文字替換

### Function Schema
修改 `extract_name_relation_function.json` 來調整輸出格式：
- 可以修改 `properties` 來改變輸出欄位
- 可以修改 `required` 來改變必填欄位

## 注意事項
1. 確保OpenAI API Key已正確配置
2. 模板檔案使用UTF-8編碼
3. 所有API呼叫都有錯誤處理和日誌記錄
4. 建議在生產環境中使用環境變數來存儲API Key 